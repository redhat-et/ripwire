#!/usr/bin/env bash
# anchorhopcheck.sh — the R1 gate: anchor-hop expansion (LARGER-style) on the conceptual --for route.
#
#   test/anchorhopcheck.sh                        # uses build/ctxpack on test/anchorhopfix
#   CTXPACK_BIN=asan/ctxpack test/anchorhopcheck.sh
#
# R1 (PLAN_audit5Public2026 "Hard parts — R1 anchor-hop expansion design"): on the CONCEPTUAL
# (subtoken+body) route ONLY, the top-m ranked anchors propagate α·anchorScore·ω(edge) to their 1-hop
# call/import/decl-use neighbours (ω = 1/(1+ambOut) at the edge's call site), θ-filtered and capped at
# 2m additions, and the union is re-ranked — so a zero-lexical-overlap direct callee of the top anchor
# surfaces in the bundle. The name-exact route and --no-route are BYTE-IDENTICAL to pre-R1. This gate asserts:
#   (1) EXPANSION — drainStaleVaultRows (a callee of the top anchor sharing NO query token) appears in
#       the DEFAULT conceptual --for top-4, and does NOT appear in the --no-route top-4 (plain lexical).
#   (2) NO-ROUTE NO-REGRESSION — --no-route output is byte-identical run-to-run AND carries neither a
#       'routed:' nor an 'anchor-hop' note (expansion must not leak into the opt-out path).
#   (3) NAME-EXACT NO-REGRESSION — an identifier query routes to name-exact and its output is
#       byte-identical to the same query with expansion force-disabled (CTXPACK_NO_ANCHORHOP=1):
#       expansion never touches the name-exact route.
#   (4) determinism + xmllint on the expanded bundle; the header self-declares the hop expansion.
#   (5) MUTATION self-test — the expansion assertion fails against the --no-route run (it is live).
# The fixture is copied to a tmp dir OUTSIDE any git repo and scanned via a RELATIVE path, so output
# carries no churn/co-change attrs and no absolute paths — stable across machines and time.
# Exits non-zero on any failure.

set -u
ROOT="$( cd "$( dirname "$0" )/.." && pwd )"
BIN="${CTXPACK_BIN:-$ROOT/build/ctxpack}"
[ "${BIN#/}" = "$BIN" ] && BIN="$ROOT/$BIN"          # allow a repo-relative CTXPACK_BIN
TMP="$( mktemp -d )"; trap 'rm -rf "$TMP"' EXIT
fail=0
ok(){ printf '  PASS  %s\n' "$*"; }
no(){ printf '  FAIL  %s\n' "$*"; fail=1; }

[ -x "$BIN" ] || { echo "no ctxpack binary at $BIN — build first (cmake --build build -j)"; exit 2; }
echo "anchorhopcheck: BIN=$BIN"

# fixture copy: sources only, relative path, outside any git repo
mkdir -p "$TMP/anchorhopfix"
cp "$ROOT"/test/anchorhopfix/*.cpp "$TMP/anchorhopfix/"
cd "$TMP"
QUERY="reconcile shipment ledger"

# ── (1) EXPANSION — the zero-overlap direct callee surfaces in the DEFAULT conceptual top-4 ───────────
DEFAULT4="$( "$BIN" anchorhopfix --no-cache --for="$QUERY" --pack-top-n=4 2>/dev/null )"
NOROUTE4="$( "$BIN" anchorhopfix --no-cache --for="$QUERY" --pack-top-n=4 --no-route 2>/dev/null )"
printf '%s' "$NOROUTE4" | grep -q 'drainStaleVaultRows' \
    && no "--no-route top-4 wrongly contains the zero-overlap callee (fixture no longer discriminates)" \
    || ok "--no-route (plain lexical) top-4 excludes drainStaleVaultRows (lexically invisible, as designed)"
printf '%s' "$DEFAULT4" | grep -q 'drainStaleVaultRows' \
    && ok "DEFAULT conceptual top-4 surfaces drainStaleVaultRows (anchor-hop expansion is on by default)" \
    || no "DEFAULT conceptual top-4 missing drainStaleVaultRows — anchor-hop expansion did not propagate"
# the anchors themselves must survive the re-rank (lexical stays dominant — never drowned by the hop mass)
printf '%s' "$DEFAULT4" | grep -q 'reconcileShipmentLedger' \
    && ok "DEFAULT top-4 keeps the top lexical anchor itself (reconcileShipmentLedger)" \
    || no "expanded rank drowned the top lexical anchor — re-rank is broken"

# ── (2) NO-ROUTE NO-REGRESSION — byte-stable, no routed/hop notes ─────────────────────────────────────
"$BIN" anchorhopfix --no-cache --for="$QUERY" --no-route >"$TMP/nr1.xml" 2>/dev/null
"$BIN" anchorhopfix --no-cache --for="$QUERY" --no-route >"$TMP/nr2.xml" 2>/dev/null
diff -q "$TMP/nr1.xml" "$TMP/nr2.xml" >/dev/null && ok "--no-route deterministic run-to-run" || no "--no-route non-deterministic"
{ ! grep -q 'routed:' "$TMP/nr1.xml"; } && { ! grep -q 'anchor-hop' "$TMP/nr1.xml"; } \
    && ok "--no-route carries neither a 'routed:' nor an 'anchor-hop' note (expansion cannot leak into the opt-out)" \
    || no "--no-route output carries a routed/anchor-hop note — expansion leaked into the opt-out path"

# ── (3) NAME-EXACT NO-REGRESSION — expansion never touches the name-exact route ───────────────────────
"$BIN" anchorhopfix --no-cache --for="reconcileShipmentLedger" >"$TMP/ne_default.xml" 2>/dev/null
CTXPACK_NO_ANCHORHOP=1 "$BIN" anchorhopfix --no-cache --for="reconcileShipmentLedger" >"$TMP/ne_nohop.xml" 2>/dev/null
grep -q 'routed: name-exact' "$TMP/ne_default.xml" \
    && ok "identifier query still routes to name-exact (router untouched)" \
    || no "identifier query no longer routes to name-exact"
diff -q "$TMP/ne_default.xml" "$TMP/ne_nohop.xml" >/dev/null \
    && ok "name-exact route byte-identical with expansion force-disabled (expansion never fires on name-exact)" \
    || no "name-exact route bytes CHANGED when expansion was force-disabled — expansion leaked into name-exact"
{ ! grep -q 'anchor-hop' "$TMP/ne_default.xml"; } \
    && ok "name-exact bundle carries no 'anchor-hop' note" \
    || no "name-exact bundle carries an 'anchor-hop' note — wrong route expanded"

# ── (4) determinism + well-formed XML + honest header on the expanded bundle ──────────────────────────
"$BIN" anchorhopfix --no-cache --for="$QUERY" >"$TMP/h1.xml" 2>/dev/null
"$BIN" anchorhopfix --no-cache --for="$QUERY" >"$TMP/h2.xml" 2>/dev/null
diff -q "$TMP/h1.xml" "$TMP/h2.xml" >/dev/null && ok "determinism (DEFAULT conceptual --for byte-identical run-to-run)" \
                                               || no "non-deterministic expanded output"
grep -q 'anchor-hop' "$TMP/h1.xml" && ok "expanded bundle self-declares the anchor-hop expansion in the header" \
                                   || no "expanded bundle missing the anchor-hop header note"
if command -v xmllint >/dev/null 2>&1; then
    xmllint --noout "$TMP/h1.xml" 2>/dev/null && ok "xml well-formed (expanded bundle)" || no "xml malformed (expanded bundle)"
else
    ok "xml well-formed (xmllint absent — skipped)"
fi

# ── (5) MUTATION self-test — the expansion assertion must FAIL against the --no-route output ──────────
MUT="$( printf '%s' "$NOROUTE4" | grep -q 'drainStaleVaultRows' && echo BAD || echo TRIPPED )"
[ "$MUT" = "TRIPPED" ] && ok "mutation self-test (the expansion assertion fails on the --no-route run, so it is live)" \
                       || no "mutation self-test broke — the expansion assertion cannot fail"

[ "$fail" -eq 0 ] && echo "ALL PASS" || echo "SOME FAILED"
exit "$fail"
