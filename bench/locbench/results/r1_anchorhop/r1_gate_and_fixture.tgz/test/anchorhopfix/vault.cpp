// drops expired rows from the storage vault — deliberately shares NO token with the gate's query
// (BM25 also indexes THIS comment, so it must not name the caller or any query word); plain lexical
// ranking scores it 0, and only the R1 hop propagation from its caller can surface it.
void drainStaleVaultRows()
{
    int dropped = 0;
    (void)dropped;
}
