// padding symbols with ZERO query-term overlap — they sort FIRST (file name "apad") so the plain
// (--no-route / name-exact) ranking's zero-score id-tiebreak fills its tail slots from HERE, never
// from vault.cpp: only the R1 hop propagation can lift the hidden callee above these.
int parseManifestRow( int x ) { return x + 1; }

// second padding symbol, same purpose.
int emitStatusBanner( int x ) { return x + 2; }
