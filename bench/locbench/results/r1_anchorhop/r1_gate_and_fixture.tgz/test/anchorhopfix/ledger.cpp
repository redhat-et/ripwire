// reconcile shipment ledger after an import batch — the LEXICAL ANCHOR for the gate's query
// ("reconcile shipment ledger"): its name carries every query token, so it tops the subtoken+body
// BM25 ranking. Its direct callee lives in vault.cpp and shares NO query token — invisible to plain
// lexical ranking on purpose; only the R1 hop propagation (default on the conceptual route) lifts it.
void reconcileShipmentLedger()
{
    drainStaleVaultRows();
    drainStaleVaultRows();
}

// shipment ledger open — a second, weaker lexical hit (two query tokens).
void shipmentLedgerOpen()
{
    int ready = 1;
    (void)ready;
}

// shipment ledger seek — a third lexical hit (two query tokens).
int shipmentLedgerSeek( int key )
{
    return key;
}
