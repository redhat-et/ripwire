#!/usr/bin/env bash
# anchorhopprunecheck.sh — R1-cpp gate: MaxScore pruning stays ON under anchor-hop expansion, bytes exact.
#
#   test/anchorhopprunecheck.sh                        # uses build/ctxpack
#   CTXPACK_BIN=asan/ctxpack test/anchorhopprunecheck.sh
#
# R1's first landing disabled exact MaxScore pruning whenever the conceptual route expanded (the hop is a
# full-distribution consumer: a lifted candidate's base score must be its EXACT BM25 score, not a pruned 0)
# — and that pruning giveback (warm p95 +10.2% on the LocBench release protocol) was the recorded root
# cause of the cost side of R1's two-tier REJECT. R1-cpp restores pruning under expansion via the
# top-m-anchor-restricted exact bound (PLAN_audit5Public2026 R1 RESULT "future work"): the pruned pass
# keeps K' = max(consumerK, m) so the top-m anchors are provably exact, hop mass is computed from anchor
# scores + edge evidence alone (never from a candidate's own lex score), and the <=2m surviving hop
# candidates are re-scored EXACTLY on demand from the retained BM25 stats (same expressions, same order —
# bit-identical floats). This gate asserts the safety contract of that optimization:
#   (1) NON-VACUOUS — the probe queries actually fire the expansion (header carries 'anchor-hop:') AND the
#       corpus is big enough that pruning has real work to skip (src/, the repo's own largest local corpus).
#   (2) PRUNE-EQ under expansion — default (pruned) --for byte-identical to CTXPACK_NO_PRUNE=1 (exhaustive)
#       on the expanded conceptual route: production bundle, candidates top-50, and candidates top-4
#       (consumerK < m exercises the K' = max(K, m) anchor-exactness widening).
#   (3) ABLATION PRUNE-EQ — CTXPACK_NO_ANCHORHOP=1 (baseline path) pruned vs exhaustive stays byte-identical
#       (the restoration must not disturb the no-hop pruning contract postingscheck pins).
#   (4) determinism run-to-run on the pruned expanded output.
#   (5) MUTATION self-test — the hop-note assertion fails on a CTXPACK_NO_ANCHORHOP=1 run (it is live).
# Exits non-zero on any failure.

set -u
ROOT="$( cd "$( dirname "$0" )/.." && pwd )"
BIN="${CTXPACK_BIN:-$ROOT/build/ctxpack}"
[ "${BIN#/}" = "$BIN" ] && BIN="$ROOT/$BIN"          # allow a repo-relative CTXPACK_BIN
TMP="$( mktemp -d )"; trap 'rm -rf "$TMP"' EXIT
fail=0
ok(){ printf '  PASS  %s\n' "$*"; }
no(){ printf '  FAIL  %s\n' "$*"; fail=1; }

[ -x "$BIN" ] || { echo "no ctxpack binary at $BIN — build first (cmake --build build -j)"; exit 2; }
echo "anchorhopprunecheck: BIN=$BIN"
cd "$ROOT"

# conceptual queries (no identifier syntax, content words not all symbol names -> subtoken+body route);
# QSRC is known to lift 1-hop neighbours on src/ (the hop note appears), giving the equivalence teeth.
QSRC="how does the ranker decide which route to use for a conceptual retrieval task"

# ── (1) NON-VACUOUS — expansion fires on the probe query ──────────────────────────────────────────────
"$BIN" src --no-cache --for="$QSRC" >"$TMP/hop_pruned.xml" 2>/dev/null
grep -q 'anchor-hop:' "$TMP/hop_pruned.xml" \
    && ok "probe query fires the expansion on src/ (header carries the anchor-hop note)" \
    || no "probe query no longer fires the expansion on src/ — the prune-eq below would be vacuous"

# ── (2) PRUNE-EQ under expansion — pruned vs CTXPACK_NO_PRUNE=1, three consumer shapes ────────────────
pruneeq(){ # $1=label  $2…=ctxpack args
    local label="$1"; shift
    "$BIN" "$@" >"$TMP/peq_p.out" 2>/dev/null
    CTXPACK_NO_PRUNE=1 "$BIN" "$@" >"$TMP/peq_x.out" 2>/dev/null
    if diff -q "$TMP/peq_p.out" "$TMP/peq_x.out" >/dev/null; then ok "$label: pruned byte-identical to CTXPACK_NO_PRUNE=1"
    else no "$label: pruned output DIFFERS from exhaustive under expansion (unsafe bound)"; fi
}
pruneeq "expanded --for production bundle"        src --no-cache --for="$QSRC"
pruneeq "expanded --for candidates top-50"        src --no-cache --for="$QSRC" --format=candidates --top-k=50
pruneeq "expanded --for candidates top-4 (K < m)" src --no-cache --for="$QSRC" --format=candidates --top-k=4
pruneeq "expanded --pack-task bundle"             src --no-cache --pack-task="$QSRC"

# ── (3) ABLATION PRUNE-EQ — the no-hop baseline path keeps its pruning contract ───────────────────────
CTXPACK_NO_ANCHORHOP=1 "$BIN" src --no-cache --for="$QSRC" >"$TMP/nohop_p.xml" 2>/dev/null
CTXPACK_NO_ANCHORHOP=1 CTXPACK_NO_PRUNE=1 "$BIN" src --no-cache --for="$QSRC" >"$TMP/nohop_x.xml" 2>/dev/null
diff -q "$TMP/nohop_p.xml" "$TMP/nohop_x.xml" >/dev/null \
    && ok "CTXPACK_NO_ANCHORHOP=1 (baseline path) pruned byte-identical to exhaustive" \
    || no "baseline-path prune equivalence broke — the restoration disturbed the no-hop contract"

# ── (4) determinism run-to-run on the pruned expanded output ──────────────────────────────────────────
"$BIN" src --no-cache --for="$QSRC" >"$TMP/d2.xml" 2>/dev/null
diff -q "$TMP/hop_pruned.xml" "$TMP/d2.xml" >/dev/null \
    && ok "pruned expanded --for deterministic run-to-run" \
    || no "pruned expanded --for non-deterministic"

# ── (5) MUTATION self-test — the hop-note assertion is live ───────────────────────────────────────────
grep -q 'anchor-hop:' "$TMP/nohop_p.xml" \
    && no "mutation self-test broke — the hop note appears even with expansion force-disabled" \
    || ok "mutation self-test (the hop-note assertion fails on a CTXPACK_NO_ANCHORHOP=1 run, so it is live)"

[ "$fail" -eq 0 ] && echo "ALL PASS" || echo "SOME FAILED"
exit "$fail"
